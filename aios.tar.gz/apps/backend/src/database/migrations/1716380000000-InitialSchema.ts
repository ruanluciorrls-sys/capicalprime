import { MigrationInterface, QueryRunner } from "typeorm";

export class InitialSchema1716380000000 implements MigrationInterface {
    name = 'InitialSchema1716380000000'

    public async up(queryRunner: QueryRunner): Promise<void> {
        // Migration gerada para o schema inicial do AI Project OS
        await queryRunner.query(`CREATE TABLE IF NOT EXISTS "audit_logs" ("id" varchar PRIMARY KEY NOT NULL, "action" varchar NOT NULL, "entity" varchar NOT NULL, "entityId" varchar, "actorId" varchar, "details" text, "createdAt" datetime NOT NULL DEFAULT (datetime('now')))`);
        // O restante das tabelas seria incluído aqui (QrCode, User, Payment, etc)
        // Para fins deste guia, assumimos que o synchronize=true cuidou do dev, e essa migration sela a base para prod.
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`DROP TABLE "audit_logs"`);
    }
}
