import { Controller, Post, Body, Get, Delete, Param, UseGuards, Request, Res, Logger, NotFoundException } from '@nestjs/common';
import { ExtensionService } from './extension.service';
import { ApiKeyGuard } from '../../common/guards/api-key.guard';
import { Response } from 'express';
import { QrGateway } from '../qr/qr.gateway';

@Controller('extension')
export class ExtensionController {
  private readonly logger = new Logger(ExtensionController.name);

  constructor(
    private readonly extensionService: ExtensionService,
    private readonly qrGateway: QrGateway,
  ) {}

  @Post('register')
  async register(@Body() body: { deviceId: string; userApiKey: string; browser: string }) {
    return this.extensionService.registerDevice(body.deviceId, body.userApiKey, body.browser);
  }

  @Get('devices')
  @UseGuards(ApiKeyGuard)
  async getUserDevices(@Request() req) {
    const devices = await this.extensionService.getUserDevices(req.user.id);
    return devices.map(device => ({
      ...device,
      isOnline: this.qrGateway.isDeviceOnline(device.deviceId),
    }));
  }

  @Delete('devices/:deviceId')
  @UseGuards(ApiKeyGuard)
  async revokeDevice(@Param('deviceId') deviceId: string, @Request() req) {
    return this.extensionService.revokeDevice(deviceId, req.user.id);
  }

  @Post('devices/:deviceId/test')
  @UseGuards(ApiKeyGuard)
  async testDevice(@Param('deviceId') deviceId: string, @Request() req) {
    const devices = await this.extensionService.getUserDevices(req.user.id);
    const device = devices.find(d => d.deviceId === deviceId);
    if (!device) {
      throw new NotFoundException('Dispositivo não encontrado.');
    }
    const isOnline = await this.qrGateway.testDeviceConnection(deviceId);
    return { online: isOnline, deviceId, lastSeen: device.lastSeen };
  }

  @Post('heartbeat')
  async heartbeat(@Body() body: { deviceId: string; status: string; error?: string; version?: string }) {
    return this.extensionService.updateHeartbeat(body.deviceId, body.status, body.error, body.version);
  }

  @Get('download')
  @UseGuards(ApiKeyGuard)
  async downloadExtension(@Request() req, @Res() res: Response) {
    try {
      this.logger.log(`[DOWNLOAD] Gerando extensão para usuário ${req.user.id}`);
      const zipBuffer = await this.extensionService.generateExtensionZip(req.user.id);
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', `attachment; filename="aios-extension-${req.user.id}.zip"`);
      this.logger.log(`[DOWNLOAD] ZIP criado com sucesso, tamanho: ${zipBuffer.length} bytes`);
      res.send(zipBuffer);
    } catch (error) {
      this.logger.error(`[DOWNLOAD] Erro: ${(error as Error).message}`);
      res.status(500).json({ success: false, error: error instanceof Error ? error.message : 'Erro interno' });
    }
  }
}
