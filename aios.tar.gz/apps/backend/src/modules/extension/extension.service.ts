import { Injectable, UnauthorizedException, Logger } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ExtensionDeviceEntity } from '../../database/entities/extension-device.entity';
import { UserEntity } from '../../database/entities/user.entity';
import AdmZip from 'adm-zip';
import * as fs from 'fs';
import * as path from 'path';
import { randomUUID } from 'crypto';
import { EventEmitter2 } from '@nestjs/event-emitter';

@Injectable()
export class ExtensionService {
  private readonly logger = new Logger(ExtensionService.name);
  private readonly EXTENSION_VERSION = '1.0.0';

  constructor(
    @InjectRepository(ExtensionDeviceEntity)
    private deviceRepo: Repository<ExtensionDeviceEntity>,
    @InjectRepository(UserEntity)
    private userRepo: Repository<UserEntity>,
    private jwtService: JwtService,
    private eventEmitter: EventEmitter2,
  ) {}

  async registerDevice(deviceId: string, userApiKey: string, browser: string) {
    const user = await this.userRepo.findOne({ where: { apiKey: userApiKey } });
    if (!user) throw new UnauthorizedException('API Key inválida');
    const payload = { userId: user.id, deviceId };
    const deviceToken = this.jwtService.sign(payload);
    await this.deviceRepo.upsert(
      {
        deviceId,
        userId: user.id,
        deviceToken,
        browser,
        isActive: true,
        lastSeen: new Date(),
        connectionStatus: 'ONLINE',
      },
      ['deviceId'],
    );
    return { deviceToken, userId: user.id };
  }

  async getUserDevices(userId: string) {
    return this.deviceRepo.find({ where: { userId, isActive: true }, order: { lastSeen: 'DESC' } });
  }

  async revokeDevice(deviceId: string, userId: string) {
    await this.deviceRepo.update({ deviceId, userId }, { isActive: false, deviceToken: null });
    return { success: true };
  }

  async updateHeartbeat(deviceId: string, status: string, error?: string, version?: string) {
    await this.deviceRepo.update({ deviceId }, {
      lastSeen: new Date(),
      connectionStatus: status as any,
      lastError: error || null,
      version: version || undefined,
    });
    return { success: true };
  }

  async generateExtensionZip(userId: string): Promise<Buffer> {
    const user = await this.userRepo.findOne({ where: { id: userId } });
    if (!user) throw new Error('Usuário não encontrado');
    
    // Versão da extensão fixada no backend
    const currentVersion = this.EXTENSION_VERSION;
    
    // Atualiza a versão no usuário apenas para manter o histórico caso necessário
    if (user.extensionLastVersion !== currentVersion) {
      user.extensionLastVersion = currentVersion;
      await this.userRepo.save(user);
    }

    const deviceId = randomUUID();
    const deviceToken = this.jwtService.sign({ userId, deviceId }, { expiresIn: '365d' });

    await this.deviceRepo.upsert(
      {
        userId,
        deviceId,
        deviceToken,
        browser: 'Chrome Extension',
        version: currentVersion,
        isActive: true,
        lastSeen: new Date(),
        connectionStatus: 'OFFLINE',
      },
      ['deviceId'],
    );

    // Dispara evento para notificar o painel via WebSocket em tempo real
    this.eventEmitter.emit('extension.status.changed', {
      userId,
      deviceId,
      browser: 'Chrome Extension',
      version: currentVersion,
      connectionStatus: 'OFFLINE',
      isActive: true,
      lastSeen: new Date().toISOString(),
    });

    this.logger.log(`[DOWNLOAD] Versão: ${currentVersion}, Device token gerado: ${deviceToken.substring(0, 15)}...`);

    const templatePath = this.resolveTemplatePath();
    const baseApiUrl = (process.env.NEXT_PUBLIC_API_URL || process.env.BACKEND_URL || 'http://localhost:3001').replace(/\/api\/v1$/, '');
    const apiUrl = `${baseApiUrl}/api/v1`;

    const replacements: Record<string, string> = {
      '{{API_URL}}': apiUrl,
      '{{WS_URL}}': baseApiUrl,
      '{{DEVICE_TOKEN}}': deviceToken,
      '{{VERSION}}': currentVersion,
      '{{EXTENSION_VERSION}}': currentVersion,
    };

    const zip = new AdmZip();
    const textExtensions = /\.(json|js|html|txt|md|css)$/i;

    const appendFiles = (currentPath: string, zipFolder = '') => {
      const entries = fs.readdirSync(currentPath, { withFileTypes: true });
      for (const entry of entries) {
        const fullPath = path.join(currentPath, entry.name);
        // zipPath is relative to root, e.g. "manifest.json" or "icons/icon16.png"
        const zipPath = zipFolder ? `${zipFolder}/${entry.name}` : entry.name;

        if (entry.isDirectory()) {
          appendFiles(fullPath, zipPath);
          continue;
        }

        if (textExtensions.test(entry.name)) {
          let content = fs.readFileSync(fullPath, 'utf8');
          // Remove UTF-8 BOM if present
          if (content.charCodeAt(0) === 0xFEFF) content = content.slice(1);
          for (const [placeholder, value] of Object.entries(replacements)) {
            content = content.replace(new RegExp(placeholder.replace(/[{}]/g, '\\$&'), 'g'), value);
          }
          // Validate JSON files
          if (entry.name.endsWith('.json')) {
            try {
              JSON.parse(content);
            } catch (e) {
              throw new Error(`Arquivo JSON inválido após substituição: ${zipPath} — ${(e as Error).message}`);
            }
          }
          zip.addFile(zipPath, Buffer.from(content, 'utf8'), '', 0o644);
        } else {
          // Binary file — read as buffer
          const buffer = fs.readFileSync(fullPath);
          zip.addFile(zipPath, buffer, '', 0o644);
        }
      }
    };

    appendFiles(templatePath);

    // ── Incluir socket.io-client ESM browser bundle ──────────────────────────
    // O background.js usa: import { io } from './socket.io.esm.min.js'
    // O bundle precisa estar na raiz da extensão junto ao background.js
    const socketIoBundleName = 'socket.io.esm.min.js';
    const socketIoCandidates = [
      path.join(process.cwd(), 'node_modules/socket.io-client/dist', socketIoBundleName),
      path.join(process.cwd(), '../..', 'node_modules/socket.io-client/dist', socketIoBundleName),
      path.join(__dirname, '../../../../node_modules/socket.io-client/dist', socketIoBundleName),
      path.join(__dirname, '../../../../../../node_modules/socket.io-client/dist', socketIoBundleName),
    ];
    let socketIoBundleIncluded = false;
    for (const candidate of socketIoCandidates) {
      if (fs.existsSync(candidate)) {
        const bundleBuffer = fs.readFileSync(candidate);
        zip.addFile(socketIoBundleName, bundleBuffer, '', 0o644);
        this.logger.log(`socket.io-client bundle incluído no ZIP: ${candidate} (${bundleBuffer.length} bytes)`);
        socketIoBundleIncluded = true;
        break;
      }
    }
    if (!socketIoBundleIncluded) {
      this.logger.error(`AVISO: ${socketIoBundleName} não encontrado em node_modules. A extensão pode falhar ao conectar via Socket.IO.`);
    }

    // Validate manifest.json is at root
    const manifestEntry = zip.getEntry('manifest.json');
    if (!manifestEntry) {
      const entries = zip.getEntries().map(e => e.entryName).join(', ');
      throw new Error(`manifest.json não encontrado na raiz do ZIP. Entradas: ${entries}`);
    }

    this.logger.log(`ZIP gerado para userId=${userId} deviceId=${deviceId} — ${zip.getEntries().length} arquivos`);
    return zip.toBuffer();
  }

  private resolveTemplatePath(): string {
    const candidates = [
      // When running from apps/backend/ (dev/prod) — prefer the leaf folder with manifest.json
      path.join(process.cwd(), 'templates/extension/extension-template'),
      path.join(process.cwd(), 'templates/extension'),
      // When running from monorepo root
      path.join(process.cwd(), 'apps/backend/templates/extension/extension-template'),
      path.join(process.cwd(), 'apps/backend/templates/extension'),
    ];

    for (const candidate of candidates) {
      if (fs.existsSync(candidate) && fs.existsSync(path.join(candidate, 'manifest.json'))) {
        this.logger.log(`Template da extensão encontrado em: ${candidate}`);
        return candidate;
      }
    }

    const searched = candidates.join('\n  ');
    this.logger.error(`Template da extensão não encontrado.\nCaminhos verificados:\n  ${searched}`);
    throw new Error('Template da extensão não encontrado. Verifique a pasta templates/extension/extension-template.');
  }
}
