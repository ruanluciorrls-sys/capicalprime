import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuditLogEntity } from '../database/entities/audit-log.entity';
import { EncryptionService } from './services/encryption.service';
import { AuditLogService } from './services/audit-log.service';
import { CacheService } from './services/cache.service';

@Module({
  imports: [TypeOrmModule.forFeature([AuditLogEntity])],
  providers: [EncryptionService, AuditLogService, CacheService],
  exports: [TypeOrmModule, EncryptionService, AuditLogService, CacheService],
})
export class CommonModule {}
