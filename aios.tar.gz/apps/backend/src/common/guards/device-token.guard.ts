import {
  CanActivate, ExecutionContext, Injectable, UnauthorizedException
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ExtensionDeviceEntity } from '../../database/entities/extension-device.entity';

@Injectable()
export class DeviceTokenGuard implements CanActivate {
  constructor(
    private readonly jwtService: JwtService,
    @InjectRepository(ExtensionDeviceEntity)
    private readonly deviceRepo: Repository<ExtensionDeviceEntity>,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const authHeader = request.headers['authorization'] as string;

    if (!authHeader?.startsWith('Bearer ')) {
      throw new UnauthorizedException('Device token ausente.');
    }

    const token = authHeader.substring(7);

    try {
      const payload = this.jwtService.verify(token);
      const device = await this.deviceRepo.findOne({
        where: { deviceId: payload.deviceId, deviceToken: token, isActive: true },
      });

      if (!device) {
        throw new UnauthorizedException('Dispositivo não registrado ou desativado.');
      }

      // Update last seen
      await this.deviceRepo.update(device.id, { lastSeen: new Date() });

      request.device = device;
      return true;
    } catch (err) {
      throw new UnauthorizedException('Device token inválido ou expirado.');
    }
  }
}
