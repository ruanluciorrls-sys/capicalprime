import { CONFIG } from './config.js';

const statusDot  = document.getElementById('statusDot');
const statusText = document.getElementById('statusText');
const versionSpan = document.getElementById('version');
const testBtn    = document.getElementById('testBtn');
const resultDiv  = document.getElementById('test-result');

// Exibe a versão imediatamente (CONFIG já está disponível pois é módulo)
versionSpan.textContent = CONFIG.VERSION;

function updateUI(connected) {
  statusDot.className = connected ? 'dot connected' : 'dot';
  statusText.textContent = connected ? 'Conectado' : 'Desconectado';
}

// Solicita status ao background assim que o popup abre
chrome.runtime.sendMessage({ type: 'GET_STATUS' }, (res) => {
  if (chrome.runtime.lastError) {
    // SW ainda acordando — mostra "Aguardando..." e espera WS_STATUS
    statusText.textContent = 'Aguardando...';
    return;
  }
  if (res) updateUI(res.connected);
});

// Escuta atualizações push do background (quando socket conecta/desconecta)
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'WS_STATUS') updateUI(msg.connected);
});

// Botão de teste
testBtn.addEventListener('click', () => {
  resultDiv.textContent = 'Enviando...';
  testBtn.disabled = true;
  chrome.runtime.sendMessage({ type: 'TEST_QR' }, (response) => {
    testBtn.disabled = false;
    if (chrome.runtime.lastError) {
      resultDiv.textContent = '❌ Erro: ' + chrome.runtime.lastError.message;
    } else if (response?.ok) {
      resultDiv.textContent = '✅ Teste enviado!';
    } else {
      resultDiv.textContent = '❌ Falha: ' + (response?.error || 'Sem resposta');
    }
    setTimeout(() => { resultDiv.textContent = ''; }, 4000);
  });
});
