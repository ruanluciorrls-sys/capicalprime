// background.js — AI OS Pix Capture Extension (Manifest V3 Service Worker)
// Usa socket.io-client (ESM) — compatível com NestJS Gateway Socket.IO

import { io } from './socket.io.esm.min.js';
import { CONFIG } from './config.js';

let socket = null;
let wsConnected = false;

// ── Status do Socket.IO ──────────────────────────────────────
function updateConnectionStatus(connected) {
  wsConnected = connected;
  chrome.storage.local.set({ wsConnected: connected });
  // Notifica o popup (falha silenciosamente se não estiver aberto)
  chrome.runtime.sendMessage({ type: 'WS_STATUS', connected }).catch(() => {});
}

// ── Conexão Socket.IO ────────────────────────────────────────
// CONFIG.WS_URL = http://localhost:3001 (sem /api/v1)
// O socket.io-client cuida do upgrade HTTP → WebSocket automaticamente.
function connectSocket() {
  socket = io(CONFIG.WS_URL, {
    transports: ['websocket'],          // força WebSocket, evita polling
    auth: { token: CONFIG.DEVICE_TOKEN },
    reconnection: true,
    reconnectionAttempts: Infinity,
    reconnectionDelay: 2000,
    reconnectionDelayMax: 30000,
    randomizationFactor: 0.3,
    timeout: 10000,
  });

  socket.on('connect', () => {
    console.log('[EXTENSION] Socket.IO conectado', socket.id);
    updateConnectionStatus(true);
  });

  socket.on('disconnect', (reason) => {
    console.log('[EXTENSION] Socket.IO desconectado:', reason);
    updateConnectionStatus(false);
  });

  socket.on('connect_error', (err) => {
    console.error('[EXTENSION] Socket.IO erro:', err.message);
    updateConnectionStatus(false);
  });

  // Eventos vindos do backend (ex: confirmação de aprovação)
  socket.on('QR_STATUS_UPDATE', (data) => {
    console.log('[EXTENSION] QR_STATUS_UPDATE recebido:', data);
  });

  // Responde a testes de ping do painel
  socket.on('ping', (data) => {
    if (data?.deviceId) {
      socket.emit('pong', { deviceId: data.deviceId });
    }
  });
}

connectSocket();

// ── Cache local de hashes enviados (evita reenvio por 10 min) ──────────
// Separado do dedup global do backend (que é permanente).
// Aqui é apenas para não fazer spam enquanto o scanner roda a cada 5s.
const sentHashes = new Map();

// ── Funções de Validação ─────────────────────────────────────
function normalizePixPayload(text) {
  if (!text) return '';
  return String(text)
    .replace(/\s+/g, '')
    .replace(/\u200B|\u200C|\u200D/g, '') // zero-width spaces
    .trim();
}

function isValidPixPayload(payload) {
  if (!payload) return false;
  const clean = normalizePixPayload(payload);
  if (clean.length < 80) return false;
  if (!clean.startsWith('000201')) return false;
  if (!clean.toLowerCase().includes('br.gov.bcb.pix')) return false;

  // Validação universal do campo CRC16: "6304" + 4 caracteres hexadecimais no final do código
  const crcMatch = /6304[0-9a-fA-F]{4}$/.test(clean);
  if (!crcMatch) return false;

  return true;
}

// ── SHA-256 via Web Crypto API (retorna hex de 64 chars) ────
async function sha256(text) {
  const data = new TextEncoder().encode(text);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

// ── Envio de QR via fetch HTTP ───────────────────────────────
// O envio usa fetch (HTTP), não o socket — o socket é apenas para receber eventos.
// CONFIG.API_URL = http://localhost:3001/api/v1
async function sendQr(payload, metadata = {}) {
  // Calcular hash SHA-256 do payload (obrigatório pelo backend: exatamente 64 chars)
  const payloadHash = await sha256(payload);
  console.log('[EXTENSION] payloadHash gerado:', payloadHash, 'tamanho:', payloadHash.length);

  const response = await fetch(`${CONFIG.API_URL}/qr/ingest`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${CONFIG.DEVICE_TOKEN}`
    },
    body: JSON.stringify({
      payload,
      payloadHash,
      sourceUrl: metadata.sourceUrl || 'chrome-extension://scanner',
      capturedAt: metadata.capturedAt || new Date().toISOString(),
      isTest: !!metadata.isTest
    })
  });

  // 409 = já recebido pelo servidor — tratar como sucesso silencioso
  if (response.status === 409) {
    console.log('[EXTENSION] QR duplicado (409) — ignorado');
    return { ok: true, duplicate: true };
  }

  if (!response.ok) {
    const errText = await response.text().catch(() => `HTTP ${response.status}`);
    throw new Error(`HTTP ${response.status}: ${errText}`);
  }

  return response.json().catch(() => ({ ok: true }));
}

// ── Payload de teste único ───────────────────────────────────
function getUniqueTestPayload() {
  const ts = Date.now();
  const rand = Math.random().toString(36).slice(2, 8).toUpperCase();
  return `00020101021226580014BR.GOV.BCB.PIX0136${rand}-${ts}52040000530398654040.015802BR5909AIOS TEST6008BRASILIA62070503***6304CAFE`;
}

// ── Keep-alive (evita que o Service Worker duerma) ───────────
chrome.alarms.create('keepAlive', { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener(() => {
  // Ping leve para manter o SW ativo
  fetch(`${CONFIG.API_URL}/health`).catch(() => {});
  // Reconecta se o socket foi perdido
  if (socket && !socket.connected) {
    socket.connect();
  }
});

// ── Message handler ──────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'QR_DETECTED') {
    sendQr(msg.payload, msg.sourceUrl, false)
      .then(data => sendResponse({ ok: true, data }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true; // resposta assíncrona
  }

  if (msg.type === 'TEST_QR') {
    const payload = getUniqueTestPayload();
    sendQr(payload, { sourceUrl: 'chrome-extension://test', isTest: true })
      .then(result => {
        console.log('[TEST] QR fake enviado com sucesso, resposta:', result);
        sendResponse({ ok: true, result });
      })
      .catch(err => {
        console.error('[EXTENSION] Erro ao enviar test QR:', err.message);
        sendResponse({ ok: false, error: err.message });
      });
    return true; // resposta assíncrona
  }

  if (msg.type === 'GET_STATUS') {
    // Responde imediatamente com o estado em memória (síncrono, sem delay de storage).
    // Se o SW acabou de acordar, wsConnected = false mas o socket.on('connect')
    // vai disparar WS_STATUS assim que reconectar, atualizando o popup.
    sendResponse({ connected: wsConnected });
    return false; // síncrono — sem return true aqui
  }

  // ── PIX_CODE_DETECTED: captura oficial do content script ────────
  if (msg.type === 'PIX_CODE_DETECTED') {
    console.log('[BACKGROUND] Mensagem recebida:', msg.type);
    const { payload, metadata } = msg;

    (async () => {
      try {
        if (!payload) throw new Error('Payload vazio');

        const hash = await sha256(payload);
        const now = Date.now();

        // Limpeza de cache local (10 min) para hash não persistir infinitamente na RAM
        for (const [h, timestamp] of sentHashes.entries()) {
          if (now - timestamp > 10 * 60 * 1000) sentHashes.delete(h);
        }

        if (sentHashes.has(hash)) {
          console.log('[BACKGROUND] Hash já enviado, ignorando duplicata.');
          sendResponse({ ok: false, error: 'duplicate_local' });
          return;
        }

        console.log('[BACKGROUND] QR_CODE_CAPTURED recebido, encaminhando para /ingest.');
        const result = await sendQr(payload, metadata || {});
        
        if (result && result.duplicate) {
          sentHashes.set(hash, Date.now());
          sendResponse({ ok: false, error: 'duplicate_global' });
          return;
        }

        sentHashes.set(hash, Date.now());
        console.log('[BACKGROUND] Resposta do backend: sucesso.');
        sendResponse({ ok: true });

      } catch (err) {
        console.error('[BACKGROUND] Resposta do backend: erro -', err.message);
        sendResponse({ ok: false, error: err.message });
      }
    })();

    return true; // resposta assíncrona
  }

  // ── RAW_QR_CAPTURED: captura bruta (sem validação estrita) ────────
  if (msg.type === 'RAW_QR_CAPTURED') {
    const { rawContent, metadata } = msg;

    (async () => {
      try {
        if (!rawContent) throw new Error('Conteúdo bruto vazio');

        const rawHash = await sha256(rawContent);
        const now = Date.now();

        // Limpeza de cache local (10 min) para hash não persistir infinitamente na RAM
        for (const [h, timestamp] of sentHashes.entries()) {
          if (now - timestamp > 10 * 60 * 1000) sentHashes.delete(h);
        }

        if (sentHashes.has(rawHash)) {
          console.log('[BACKGROUND] Captura repetida ignorada.');
          sendResponse({ ok: false, error: 'duplicate_local' });
          return;
        }

        const payloadToSend = {
          rawContent: rawContent,
          rawHash: rawHash,
          sourceUrl: metadata?.sourceUrl || 'chrome-extension://scanner',
          pageTitle: metadata?.pageTitle || '',
          captureMethod: metadata?.captureMethod || 'unknown',
          capturedAt: metadata?.capturedAt || new Date().toISOString(),
          
          // User expected custom payload format
          type: "qr_code_captured",
          qrCode: rawContent,
          source: "extension",
          timestamp: metadata?.capturedAt || new Date().toISOString(),
          orderId: null,
          amount: null
        };

        console.log('[BACKGROUND] Payload enviado ao painel:', JSON.stringify(payloadToSend, null, 2));

        const response = await fetch(`${CONFIG.API_URL}/qr/raw-capture`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${CONFIG.DEVICE_TOKEN}`
          },
          body: JSON.stringify(payloadToSend)
        });

        // 409 = backend ja tem
        if (response.status === 409) {
          sentHashes.set(rawHash, Date.now());
          console.log(`[BACKGROUND] Resposta do painel: { status: 409, message: "Duplicate on backend" }`);
          sendResponse({ ok: false, error: 'duplicate_global' });
          return;
        }

        if (!response.ok) {
          const errText = await response.text();
          throw new Error(`Backend respondeu HTTP ${response.status}: ${errText}`);
        }

        const responseData = await response.json().catch(() => ({}));
        sentHashes.set(rawHash, Date.now());

        console.log(`[BACKGROUND] Resposta do painel: { status: ${response.status}, body: ${JSON.stringify(responseData)} }`);
        sendResponse({ ok: true });

      } catch (err) {
        console.error('[BACKGROUND] Erro ao enviar QR Code para o painel:', err.message);
        sendResponse({ ok: false, error: err.message });
      }
    })();

    return true; // resposta assíncrona
  }
});
