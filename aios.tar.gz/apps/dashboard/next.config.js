/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  output: 'standalone',   // Necessário para deploy Docker/Hetzner
  transpilePackages: ['@aios/shared'],
  typescript: {
    ignoreBuildErrors: true,
  },
  eslint: {
    ignoreDuringBuilds: true,
  },
  optimizeFonts: false,
  async rewrites() {
    // Força IPv4 (127.0.0.1) para evitar ECONNREFUSED ::1 no Windows
    const apiBase = (process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001')
      .replace('localhost', '127.0.0.1');
    return [
      {
        source: '/api/:path*',
        destination: `${apiBase}/api/v1/:path*`,
      },
    ];
  },
};
export default nextConfig;
