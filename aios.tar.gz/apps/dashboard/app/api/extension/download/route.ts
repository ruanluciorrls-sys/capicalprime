import { NextRequest } from 'next/server';

export async function GET(request: NextRequest) {
  const apiKey = request.headers.get('x-api-key');
  if (!apiKey) {
    return new Response(JSON.stringify({ message: 'API Key ausente.' }), {
      status: 401,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  const backendBase = process.env.NEXT_PUBLIC_API_URL || process.env.BACKEND_URL || 'http://127.0.0.1:3001';
  const response = await fetch(`${backendBase}/api/v1/extension/download`, {
    headers: { 'X-Api-Key': apiKey },
  });

  if (!response.ok) {
    const text = await response.text();
    return new Response(text || JSON.stringify({ message: 'Falha ao baixar extensao.' }), {
      status: response.status,
      headers: { 'Content-Type': response.headers.get('content-type') || 'application/json' },
    });
  }

  const file = await response.arrayBuffer();
  return new Response(file, {
    status: 200,
    headers: {
      'Content-Type': 'application/zip',
      'Content-Disposition': 'attachment; filename="capital-prime-extension.zip"',
    },
  });
}
