/**
 * Versão atual do sistema Capital Prime.
 * Mantenha sincronizado com `apps/dashboard/package.json` → "version".
 *
 * Exibida em:
 *  - Painel Admin (header, badge ao lado do título)
 *  - Tela de Login (rodapé)
 */
export const APP_VERSION = '2.2.9';
export const APP_VERSION_LABEL = `v${APP_VERSION}`;
