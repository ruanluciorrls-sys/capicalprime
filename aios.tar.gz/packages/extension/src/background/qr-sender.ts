export class QrSender {
  private readonly apiUrl = 'http://localhost:3001/api/v1'; // TODO: Config
  private lastError: string | null = null;

  constructor(private token: string) {}

  setToken(token: string) {
    this.token = token;
  }

  async send(data: { payload: string; payloadHash: string; sourceUrl: string; isTest?: boolean }): Promise<boolean> {
    try {
      this.lastError = null;
      const res = await fetch(`${this.apiUrl}/qr/ingest`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.token}`
        },
        body: JSON.stringify({
          payload: data.payload,
          payloadHash: data.payloadHash,
          sourceUrl: data.sourceUrl,
          capturedAt: new Date().toISOString(),
          isTest: !!data.isTest,
        })
      });

      if (res.status === 409) {
        console.log('QR Code ignorado pelo backend (duplicado globalmente)');
        return true; // Sucesso, já processado
      }

      if (res.status === 401) {
        this.lastError = 'Token invalido ou expirado';
        console.error('Token inválido ou expirado');
        return false;
      }

      if (!res.ok) {
        const errorText = await res.text();
        this.lastError = `Falha ao enviar QR Code: ${errorText}`;
        console.error('Falha ao enviar QR Code', errorText);
        return false;
      }

      console.log('QR Code enviado com sucesso!');
      return true;
    } catch (err) {
      this.lastError = 'Falha na conexao com o servidor';
      console.error('Erro de rede ao enviar QR Code', err);
      return false;
    }
  }

  async sendRaw(data: { rawContent: string; rawHash: string; sourceUrl: string; isTest?: boolean }): Promise<boolean> {
    try {
      this.lastError = null;
      const res = await fetch(`${this.apiUrl}/qr/raw-capture`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.token}`
        },
        body: JSON.stringify({
          rawContent: data.rawContent,
          rawHash: data.rawHash,
          sourceUrl: data.sourceUrl,
          capturedAt: new Date().toISOString(),
          isTest: !!data.isTest,
        })
      });

      if (res.status === 409) {
        console.log('Captura bruta ignorada pelo backend (duplicado globalmente)');
        return true;
      }

      if (res.status === 401) {
        this.lastError = 'Token invalido ou expirado';
        console.error('Token inválido ou expirado');
        return false;
      }

      if (!res.ok) {
        const errorText = await res.text();
        this.lastError = `Falha ao enviar captura bruta: ${errorText}`;
        console.error('Falha ao enviar captura bruta', errorText);
        return false;
      }

      console.log('Captura bruta enviada com sucesso!');
      return true;
    } catch (err) {
      this.lastError = 'Falha na conexao com o servidor';
      console.error('Erro de rede ao enviar captura bruta', err);
      return false;
    }
  }

  async heartbeat(deviceId: string, status: 'ONLINE' | 'OFFLINE' | 'ERROR') {
    try {
      await fetch(`${this.apiUrl}/extension/heartbeat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.token}`
        },
        body: JSON.stringify({ deviceId, status, error: this.lastError ?? undefined })
      });
    } catch (err) {
      // Ignore heartbeat errors
    }
  }

  getLastError() {
    return this.lastError;
  }
}
