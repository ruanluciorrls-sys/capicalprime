﻿// service-worker.ts â€” Capital Prime Extension (Manifest V3)

import { io } from 'socket.io-client';
import { QrDedup } from '../lib/qr-dedup';
import { DeviceRegistry } from './device-registry';
import { QrSender } from './qr-sender';

const registry = new DeviceRegistry();
const dedup = new QrDedup();
let sender: QrSender | null = null;
let wsConnected = false;
let socket: ReturnType<typeof io> | null = null;
let initialized = false;
let connecting = false; // guard: evita criar mÃºltiplos sockets em paralelo

function normalizePixText(text: string) {
  return String(text || '')
    .replace(/\s+/g, '')
    .replace(/\u200B|\u200C|\u200D/g, '')
    .trim();
}

function isPixCandidate(text: string) {
  const clean = normalizePixText(text);
  return (
    clean.length >= 80 &&
    clean.startsWith('000201') &&
    clean.toLowerCase().includes('br.gov.bcb.pix') &&
    /6304[A-F0-9]{4}$/i.test(clean)
  );
}

// â”€â”€ ensureInit â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
// CRÃTICO para Manifest V3: o SW pode ser morto a qualquer momento.
// Quando renasce, as variÃ¡veis em memÃ³ria estÃ£o zeradas.
// ensureInit() restaura o estado a partir do storage.
async function ensureInit() {
  if (initialized && sender) return;

  await dedup.load();
  const token = await registry.getToken();
  if (token) {
    sender = new QrSender(token);
    if (!socket?.connected) {
      await connectSocket();
    }
  }
  initialized = true;
  console.log(`[EXTENSION] ensureInit concluÃ­do | sender=${sender ? 'ok' : 'null'}`);
}

// â”€â”€ Status do Socket.IO â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
function updateConnectionStatus(connected: boolean) {
  wsConnected = connected;
  chrome.storage.local.set({ wsConnected: connected });
  chrome.runtime.sendMessage({ type: 'WS_STATUS', connected }).catch(() => {});
}

// â”€â”€ ConexÃ£o Socket.IO â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
async function connectSocket() {
  const token = await registry.getToken();
  if (!token) return;
  if (socket?.connected) return;
  if (connecting) return; // evita corrida ao chamar connectSocket() em paralelo

  connecting = true;
  try {
    // DestrÃ³i socket anterior para nÃ£o acumular listeners
    if (socket) {
      socket.removeAllListeners();
      socket.disconnect();
      socket = null;
    }

    const wsUrl = 'http://localhost:3001';

    socket = io(wsUrl, {
      transports: ['websocket'],
      auth: { token },
      reconnection: true,
      reconnectionAttempts: Infinity,
      reconnectionDelay: 2000,
      reconnectionDelayMax: 30000,
      randomizationFactor: 0.3,
      timeout: 10000,
    });

    socket.on('connect', () => {
      console.log('[EXTENSION] Socket.IO conectado', socket?.id);
      updateConnectionStatus(true);
    });

    socket.on('disconnect', (reason: string) => {
      console.log('[EXTENSION] Socket.IO desconectado:', reason);
      updateConnectionStatus(false);
    });

    socket.on('connect_error', (err: Error) => {
      console.error('[EXTENSION] Socket.IO erro:', err.message);
      updateConnectionStatus(false);
    });

    socket.on('QR_STATUS_UPDATE', (data: unknown) => {
      console.log('[EXTENSION] QR_STATUS_UPDATE recebido:', data);
    });
  } finally {
    connecting = false;
  }
}

// â”€â”€ InicializaÃ§Ã£o â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
async function init() {
  await ensureInit();
  await reportHeartbeat();
}

init();

// â”€â”€ Handlers de mensagem â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
chrome.runtime.onMessage.addListener((msg, _senderTab, sendResponse) => {

  // PIX_CODE_DETECTED/QR_DETECTED â€” vem do content script ao detectar QR na pÃ¡gina
  // ATENÃ‡ÃƒO: retorna `true` OBRIGATORIAMENTE para manter o canal aberto durante
  // o processamento assÃ­ncrono. Sem isso, o SW fecha antes de terminar.
  if (msg.type === 'PIX_CODE_DETECTED' || msg.type === 'QR_DETECTED') {
    console.log('[BACKGROUND] PIX_CODE_DETECTED recebido');
    ensureInit()
      .then(() => handleDetectedQr(msg.payload, msg.sourceUrl))
      .then((result) => sendResponse(result))
      .catch((err) => {
        console.error('[EXTENSION] Erro ao processar PIX_CODE_DETECTED:', err);
        sendResponse({ ok: false, error: String(err) });
      });
    return true; // â† CRÃTICO: mantÃ©m canal aberto para resposta assÃ­ncrona
  }

  if (msg.type === 'TEST_QR') {
    ensureInit()
      .then(() => runTestCapture())
      .then((success) => {
        console.log('[EXTENSION] Test QR enviado, resposta:', { success });
        sendResponse({ ok: success, success });
      })
      .catch((err) => {
        console.error('[EXTENSION] Erro ao enviar test QR:', err);
        sendResponse({ ok: false, success: false, error: String(err) });
      });
    return true;
  }

  if (msg.type === 'GET_STATUS') {
    chrome.storage.local.get(['wsConnected'], (res) => {
      sendResponse({ connected: res.wsConnected === true });
    });
    return true;
  }

  return false;
});

// â”€â”€ LÃ³gica de captura â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
async function handleDetectedQr(payload: string, sourceUrl: string): Promise<{ ok: boolean; error?: string }> {
  if (!sender) {
    console.warn('[EXTENSION] âš  QR detectado mas sender Ã© null (nÃ£o vinculado).');
    notifyCapture('ExtensÃ£o nÃ£o vinculada. Acesse o popup e insira a API Key.', true);
    return { ok: false, error: 'not_linked' };
  }

  const cleanPayload = normalizePixText(payload);
  const isValid = isPixCandidate(cleanPayload);
  if (isValid) {
    console.log('[BACKGROUND] Padrão Pix validado');
  }

  const hash = await sha256(cleanPayload);
  console.log('[BACKGROUND] payloadHash gerado');

  if (dedup.has(hash)) {
    console.log('[BACKGROUND] Pix ignorado por duplicidade');
    return { ok: false, error: 'duplicate_local' };
  }

  if (isValid) {
    const success = await sender.send({ payload: cleanPayload, payloadHash: hash, sourceUrl });

    if (success) {
      // SÃ³ adiciona ao dedup apÃ³s confirmaÃ§Ã£o do backend â€” libera slot para outro QR diferente imediatamente
      await dedup.add(hash);
      console.log('[BACKGROUND] Pix enviado ao backend');
      notifyCapture('QR capturado! Aguardando aprovaÃ§Ã£o no dashboard.');
      await reportHeartbeat();
      return { ok: true };
    } else {
      // NÃ£o adiciona ao dedup: backend rejeitou ou estava fora, deixa o content script tentar de novo
      console.error('[EXTENSION] âŒ Falha ao enviar QR ao backend (nÃ£o adicionado ao dedup).');
      notifyCapture('Falha ao enviar QR para o backend.', true);
      await reportHeartbeat();
      return { ok: false, error: 'ingest_failed' };
    }
  }

  const success = await sender.sendRaw({ rawContent: cleanPayload, rawHash: hash, sourceUrl });
  if (success) {
    await dedup.add(hash);
    console.log('[BACKGROUND] Captura enviada como raw-capture');
    await reportHeartbeat();
    return { ok: false, error: 'not_pix_candidate' };
  }

  await reportHeartbeat();
  return { ok: false, error: 'raw_capture_failed' };
}

async function runTestCapture() {
  if (!sender) return false;
  const ts = Date.now();
  const payload = `00020101021126580014BR.GOV.BCB.PIX0136123e4567-e89b-12d3-a456-42661417400052040000530398654040.015802BR5909AIOS TEST6008BRASILIA62070503***6304${ts.toString().slice(-4)}`;
  const hash = await sha256(`${payload}:${ts}`);
  const success = await sender.send({ payload, payloadHash: hash, sourceUrl: 'chrome-extension://test', isTest: true });
  notifyCapture(
    success ? 'Teste enviado! Verifique a fila do dashboard.' : 'Falha na conexÃ£o com o servidor.',
    !success,
  );
  await reportHeartbeat();
  return success;
}

async function sha256(input: string) {
  const data = new TextEncoder().encode(input);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(hashBuffer))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

function notifyCapture(message: string, isError = false) {
  try {
    chrome.runtime.sendMessage({ type: 'QR_CAPTURED', message, level: isError ? 'error' : 'success' }).catch((err) => {
      if (!err.message?.includes('Extension context invalidated')) {
        console.error('[BACKGROUND] Erro sendMessage:', err);
      }
    });
  } catch (err: any) {
    if (!err.message?.includes('Extension context invalidated')) {
      console.error('[BACKGROUND] notifyCapture erro:', err);
    }
  }
  try {
    chrome.notifications.create(`aios-${Date.now()}`, {
      type: 'basic',
      iconUrl: 'icon.png',
      title: isError ? 'Capital Prime - Erro' : 'Capital Prime',
      message,
    });
  } catch (_) {}
}

async function reportHeartbeat() {
  if (!sender) return;
  // Reconecta socket se caiu â€” sem depender de health endpoint externo
  if (!socket?.connected) {
    await connectSocket();
  }
  const deviceId = await registry.getDeviceId();
  const status = sender.getLastError() ? 'ERROR' : (wsConnected ? 'ONLINE' : 'OFFLINE');
  await sender.heartbeat(deviceId, status);
}

// â”€â”€ Keep-alive Manifest V3 â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
// Alarme a cada 30s mantÃ©m o SW ativo e reconecta se necessÃ¡rio
chrome.alarms.create('keepAlive', { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'keepAlive') {
    await ensureInit();
    if (sender) {
      if (!socket?.connected) await connectSocket();
      await reportHeartbeat();
    }
  }
});
