# CHANGELOG

## [2.2.9] - 2026-05-28

### Adicionado (Visual Premium & Pix Automático)
- **Drawer de QRs Recebidos Aprimorado**:
  - Eliminamos o comportamento de montagem instável que causava bugs visuais e piscadas de tela. Substituímos por transições de opacidade e deslize lateral ultra-suaves baseadas em CSS (`translate-x-0` vs `translate-x-full` e `visible opacity-100` vs `invisible opacity-0 pointer-events-none`).
  - Adicionado design premium em *glassmorphism* (`background: rgba(10, 15, 26, 0.96)`, blur de `20px` e borda dourada lateral).
  - Cards de QR receberam micro-animações suaves no hover.
- **Painel de Pix Automático Integrado**:
  - Desenvolvido o painel interativo de PIX Automático integrado diretamente na parte inferior da caixa (rodapé) do drawer.
  - Sincronização e persistência em tempo real com as preferências do usuário no backend e banco de dados.
  - Botão de ativação rápida com gradiente dourado (`Ativar` / `Desativar`).
  - Seletor de tempo de delay (5s a 10s) que brilha dourado ao ser selecionado.
- **Ocultação Inteligente da Badge**:
  - O botão flutuante amarelo (**QRs**) agora desaparece de forma suave quando o drawer está aberto, eliminando qualquer sobreposição ou impedimento físico ao botão de ativação rápida no rodapé.
- **Reestruturação Completa do Header**:
  - Mantivemos o logo **Capital Prime / Pix Dashboard** centralizado no meio absoluto do topo (`absolute left-1/2 -translate-x-1/2`) com maior destaque visual (fonte de `22px` para o título e `11px` para o subtítulo).
  - Movidos os componentes de **Saldo** (no tamanho compacto de `14px`) e **AsaasSummary** para o lado **direito** da barra superior, gerando um visual limpo e extremamente profissional.
  - Removido o botão de **Extensões** e a caixa de status **WS Online** redundantes da barra superior, limpando o excesso de ruído visual.

## [2.2.8] - 2026-05-28

### Adicionado (Limpeza Real do Painel)
- Novo endpoint seguro de limpeza:
  - `DELETE /api/v1/payments/cleanup-failures`
- A limpeza remove apenas registros de falha/rejeicao do proprio usuario:
  - pagamentos com status `FAILED`
  - QRs com status `REJECTED`/`ERROR`/`CANCELLED` que ficaram sem pagamento vinculado
- Nao remove pagamentos `SUCCESS`, `PENDING` ou `PROCESSING`.

### Alterado (Dashboard)
- Em **Pagamentos Recentes**, o botao agora executa limpeza real uma unica vez:
  - `Apagar falhas/rejeitos (1x)`
  - sincroniza o painel apos a limpeza recarregando pagamentos e QRs
  - depois marca como `Limpeza executada`

## [2.2.7] - 2026-05-28

### Alterado (Layout Sidebar)
- Nome da marca no topo (`Capital Prime`) centralizado na parte superior da sidebar.
- Tipografia da marca aumentada para maior destaque visual.
- Subtitulo `Pix Dashboard` ajustado para manter leitura e hierarquia sem afetar funcionalidades.
- Alteracao apenas visual, sem impacto em fluxo de pagamentos, navegacao, socket ou backend.

## [2.2.6] - 2026-05-28

### Corrigido (Build Dashboard)
- Corrigido erro de build em `/reset-password` causado por `useSearchParams` sem `Suspense`.
- A pagina foi ajustada para renderizar o conteudo dentro de `Suspense`, eliminando o erro de prerender do Next.js.

### Alterado (Admin - Pagamentos Recentes)
- O reset da tabela passou a atuar apenas sobre falhas:
  - botao `Reset falhas`: oculta somente itens com status `FAILED` na visualizacao
  - botao `Mostrar falhas`: reexibe os itens `FAILED`
- Nenhum dado de pagamento foi apagado ou alterado no banco.

## [2.2.5] - 2026-05-28

### Alterado (Dashboard)
- Adicionado reset seguro de **Pagamentos Recentes** apenas na visualizacao do painel.
- Novo botao `Reset visual` limpa a lista exibida sem apagar nem alterar dados reais.
- Novo botao `Mostrar tudo` restaura a exibicao completa do historico recente.
- Estado do reset salvo em `localStorage` para manter o comportamento entre recargas.

### Garantia
- Nenhuma alteracao em banco de dados, pagamentos, QRs, socket, token ou backend de processamento.

## [2.2.4] - 2026-05-28

### Alterado (Fluxo Manual de QR)
- O campo **"Adicionar QR Code à Fila"** agora usa a mesma regra de detecção da extensão para candidatos Pix:
  - começa com `000201`
  - contém `br.gov.bcb.pix` (case-insensitive)
  - termina com `6304XXXX`
  - comprimento mínimo de segurança
- A extração no dashboard foi trocada para regex robusta (`extractPixPayloadsFromText`), aceitando texto grande com múltiplos QRs (inclusive colados juntos).
- Corrigido o tratamento de caracteres invisíveis no parser manual (`\u200B`, `\u200C`, `\u200D`).

### Corrigido (Backend Manual)
- O endpoint manual de ingestão (`ingestManual`) foi alinhado ao fluxo da extensão:
  - valida primeiro se é **candidato Pix** (padrão universal)
  - faz parse EMV/CRC em seguida
  - se parse falhar, **não quebra o fluxo cedo**: salva como `RAW_CAPTURED` com `canPay=false`, igual ao ingest da extensão
- Mantida a deduplicação por hash e a lógica de reaproveitamento/reset de QR já existente.

## [2.2.3] - 2026-05-28

### Corrigido (Hotfix Asaas)
- Corrigido erro de pagamento com mensagem **"Informe o valor a ser transferido."** em alguns fluxos de Pix dinâmico.
- No `AsaasPaymentAdapter`, quando o pagamento dinâmico falha por ausência de `value`, o sistema agora faz **retry automático** incluindo `value`:
  - no fluxo `payViaDecodedId` (QR decodificado com ID)
  - no fluxo `payViaPayload` (fallback por payload direto)
- Mantida a lógica principal de tentar sem `value` primeiro para não quebrar cenários em que o PSP exige leitura exclusiva do valor no próprio QR.

## [2.2.2] - 2026-05-28

### Alterado (Extensao MV3)
- Detecção de payload Pix no content script padronizada para o critério universal:
  - começa com `000201`
  - contém `br.gov.bcb.pix` (case-insensitive)
  - termina com `6304` + 4 hex (`6304XXXX`)
  - tamanho mínimo de segurança
- Adicionadas funções centrais de captura:
  - `normalizePixText`
  - `isPixCandidate`
  - `extractPixPayloadsFromText`
- Varredura ativa em:
  - `document.body.innerText`
  - `input` e `textarea`
  - botões e elementos visíveis
  - clipboard (paste e clique em botão de copiar)
  - resultado de leitura visual (`jsQR`)
- Fluxo de envio atualizado:
  - content script envia `PIX_CODE_DETECTED`
  - background valida novamente antes de `/qr/ingest`
  - inválidos não vão para `/qr/ingest` e seguem para `/qr/raw-capture`
- Anti-repetição por hash SHA-256 com cooldown de 2 minutos para o mesmo payload.
- Logs operacionais adicionados para rastreio completo de captura/validação/envio.

### Mantido (Sem Quebra)
- Conexão Socket.IO/WebSocket da extensão preservada.
- `TEST_QR` preservado.
- Popup, token e vínculo de usuário preservados.

## [2.2.1] - 2026-05-27

### Corrigido (CRÍTICO)
- **"O payload informado é inválido" ao pagar PIX dinâmico via Asaas.** Três causas combinadas, todas corrigidas:
  1. **PIX dinâmico com valor fixo não deve enviar o campo `value`** — Asaas lê o valor diretamente da URL do QR. Enviar `value` diferente do embarcado (mesmo por diferença de ponto flutuante) causava rejeição imediata. Agora `payments.service.ts` detecta via `parsePix(payload).url` se é PIX dinâmico e passa `isDynamic: true` para o adapter, que omite o campo `value` no corpo da requisição.
  2. **Payload com whitespace** — chars invisíveis (espaços, `\n`, zero-width) sobreviviam do armazenamento no BD e invalidavam o payload na Asaas. Agora tanto o adapter (`pay()` e `decodeQr()`) quanto o service fazem `.replace(/\s+/g, '').trim()` antes de qualquer chamada à API.
  3. **Sem log do body completo do erro** — em falha, só loggávamos `data.errors[0].description`; o body real da Asaas ficava oculto. Agora `pay()` lê o corpo como texto, faz o parse seguro e loga `rawText.slice(0, 500)` em caso de erro, facilitando diagnóstico futuro.
- **Interface `PayPixInput`** recebeu campo `isDynamic?: boolean` com JSDoc explicando a semântica.

## [2.2.0] - 2026-05-27

### Corrigido (CRÍTICO)
- **PIX dinâmico agora exibe o valor na fila automaticamente — com fallback duplo.** Três correções combinadas:
  1. `handleQrEnrichment` checava `user.bankAdapter === 'asaas'` antes de chamar o decode; como o default no banco é `'mock'`, nenhum QR dinâmico era enriquecido. Agora busca a chave de produção diretamente em `bankConfig.asaas.production/production2/production3`, ignorando `bankAdapter`.
  2. `AsaasPaymentAdapter.decodeQr` usava `GET /pix/qrCodes/decode?payload=...` (query string), mas a API Asaas exige `POST /pix/qrCodes/decode` com body `{ payload }`. Trocado para POST + Content-Type JSON. Também ampliado o mapeamento de campos da resposta (`totalValue`, `value`, `amount`, `valor`, `transactionAmount`, `payment.value`) para cobrir variações.
  3. Adicionado **fallback BACEN direto**: nova função `fetchDynamicPixFromUrl` busca direto na URL do PIX (campo 26 sub-tag 25, ex: `qrcodes.saq.digital/v2/qr/cob/...`), decodifica JWS (3 partes base64url) ou JSON, e extrai `valor.original`/`recebedor.nome` etc. Roda como Estratégia 2 sempre que o Asaas decode não retorna `amount` válido. Timeout de 5s via `AbortSignal.timeout`.
- **Saldo principal no header puxa exclusivamente da API de produção Asaas.** `getBalance()` em `payments.service.ts` foi reescrito: percorre `production → production2 → production3`, força `baseUrl: https://api.asaas.com/v3`, e retorna `{ configured: false, available: null }` quando não há chave (em vez de `available: 0`, que escondia o saldo armazenado por causa do operador `??`).
- **Parser PIX EMV agora limpa o payload antes da decodificação TLV.** O `parsePix()` (em `packages/shared/utils/pix-parser.ts` + dist compilada) chamava `parseTLV(payload)` com o payload sujo; o `isPix()` limpava internamente, mas o `parseTLV` recebia espaços/chars invisíveis, deslocando todos os offsets e zerando amount/merchantName/pixKey. Solução: `parseTLV(clean)` com regex `\s+` + zero-width chars.
- **Ingest da extensão e ingest manual agora normalizam o payload** antes de calcular hash e parsear. Hash sempre derivado do payload limpo para dedupe consistente.
- **Default do `AsaasPaymentAdapter`** alterado de sandbox (`api-sandbox.asaas.com/v3`) para produção (`api.asaas.com/v3`) quando `baseUrl` não está no config.
- **Header do dashboard**: comparação de saldo trocada de `availableBalance ?? asaasBalance ?? null` para checagem explícita com `!== null && !== undefined`, evitando que `0` legítimo sobrescreva valor armazenado.

### Adicionado
- **Endpoints `GET/PATCH /api/admin/users/:id/preferences`** no backend (admin.controller + admin.service). Carrega/salva `autoPayEnabled`, `autoPayDelaySeconds` (5–10s) e `rotationInterval` (2–20) por usuário, com clamp de segurança nos limites.
- **Toggle PIX Automático sempre visível na fila** (`QrQueue.tsx`). Antes só aparecia quando havia QRs pendentes; agora exibe o painel também no estado vazio (`autoPayPanel` extraído para variável compartilhada).
- **Toggle PIX Automático no painel lateral** (`ManualQrPay.tsx`). Mini-switch dourado com leitura/escrita via `/api/users/me/bank-config`.
- **Versão do sistema visível em 2 lugares**: nova constante `APP_VERSION` em `apps/dashboard/lib/version.ts` (fonte única, manter sincronizada com `package.json`). Exibida como badge dourado `v2.2.0` ao lado do título "Painel Master Admin" e como rodapé `Sistema v2.2.0` abaixo do copyright na tela de login.
- **Modo batch no QR Code manual**: cole 1 ou vários payloads Pix de uma vez (um por linha **ou** colados juntos sem separador) e todos vão pra fila em sequência. Nova função `splitPayloads` detecta múltiplos QRs quebrando por `\n` e pelo prefixo `000201`. UI mostra badge "N QR Codes detectados", lista vertical de resultados (1 abaixo do outro) com status por item (pendente/enviando/sucesso/duplicado/erro), barra de progresso no botão (`Enviando 3/7...`) e resumo final (`5 adicionados • 1 duplicado • 0 erros`). Modo single (1 QR) mantém comportamento original intacto.
- **Dropdown multi-conta no saldo do header**: clicando no saldo, abre lista com nome + saldo de cada conta de produção conectada. ChevronDown indica que é clicável; fecha em click-outside via `useRef + mousedown` listener.
- **Indicador visual "Buscando valor via Asaas..."** com `Loader2` animado nos cards da fila para QRs dinâmicos enquanto o enriquecimento está em andamento (substitui o antigo `AlertCircle` que parecia erro).
- **Fallback de timeout no card da fila**: após 15s sem resposta do enriquecimento, o spinner é substituído pelo aviso "Valor indisponível — PIX dinâmico expirado ou inativo. O valor será re-consultado automaticamente ao aprovar.". Re-render automático a cada 5s via `setInterval` enquanto o QR não está enriquecido.
- **Logs detalhados de enriquecimento** no backend: `[ENRICH] Decodificando...`, `[ENRICH] ✅ enriquecido — amount=X`, `[ENRICH] PIX pode ter expirado` para facilitar debug.
- **Campo `configured: false`** na resposta de `/api/payments/balance` para distinguir "sem API configurada" de "saldo zero real".

### Alterado
- **Toasts (`react-hot-toast`)** centralizados no inferior da tela (`position="bottom-center"`) — antes era `bottom-right`.
- **Sandbox excluído do saldo principal e do `connectedCount`** no `asaasStore.ts`. O rodízio e o saldo do header agora consideram apenas slots de produção. Sandbox permanece configurável mas nunca é usado como primário.
- **Preview do `ManualQrPay`** para PIX dinâmico: texto trocado de "o valor será consultado pelo provedor durante o pagamento" para "o valor aparecerá na fila em instantes após o envio", refletindo o enriquecimento síncrono no ingest.
- **`fetchBalance` em `qrStore.ts`** trata `configured: false` mantendo `availableBalance = null` em vez de cair em `0`, garantindo que o header não exiba "R$ 0,00" quando não há config.

### Removido
- Import `useCallback` não utilizado em `app/dashboard/admin/page.tsx`.

## [10.2.0] - 2026-05-26

### Corrigido
- A captura automática de QR Code agora envia o conteúdo para o mesmo endpoint `/api/v1/qr/ingest` usado pelo botão de teste (TEST_QR).
- O backend deixou de rejeitar conteúdos que não são Pix válidos; aceita qualquer texto e marca como `RAW_CAPTURED` com `canPay=false`.
- Dashboard exibe capturas brutas com badge "⚠ Bruto" e botão de pagamento bloqueado até validação posterior.
- Removido o filtro `isPix()` do `qr-detector.ts` que impedia o envio de conteúdos reais capturados.

### Adicionado
- Cooldown de 60 segundos no `qr-detector.ts` após cada captura, evitando re-scan imediato da mesma página.
- Campos `canPay` e `isRaw` na entidade `QrCodeEntity` e no store do dashboard.
- Evento WebSocket `QR_RECEIVED` agora inclui `canPay` e `isRaw` para controle de UI no dashboard.
- Tooltip no botão Aprovar quando `canPay=false`: "Conteúdo não é um Pix válido — pagamento bloqueado até validação".

### Mantido
- TEST_QR continua funcionando — payloads Pix válidos seguem com `status=PENDING` e `canPay=true`.
- Anti-repetição por hash (QrDedup) mantida com persistência em `chrome.storage.local`.
- Compatibilidade total com capturas brutas via `/raw-capture` (endpoint separado mantido).

## [10.1.0] - 2026-05-26

### Adicionado
- Controle de repetição com pausa de 60 segundos após cada tentativa de captura.
- Comparação por hash SHA‑256 do conteúdo para evitar envios duplicados.
- Envio padronizado para o endpoint `/api/v1/qr/raw-capture`.
- Logs detalhados com mascaramento do QR Code.

### Corrigido
- Fluxo de captura automática agora envia corretamente o QR Code para o painel.
- Implementada trava `isProcessing` para evitar sobreposição de execuções.

### Mantido
- Todas as funcionalidades existentes (TEST_QR, WebSocket, popup).

## [5.4.0] - 2026-05-24

### Alterado (Apenas UI)
- Removido campo “Saldo disponível” da seção Sandbox nas configurações Asaas.
- Removido saldo do card superior da conta conectada, exibindo agora apenas nome, agência e conta.

### Corrigido (Captura de Dados da Conta)
- Implementada dupla verificação ao buscar os dados da conta Asaas. Como o endpoint `/accounts` lista apenas subcontas, a extração de dados falhava (Agência, Conta e Titular nulos) para usuários "padrão" sem contas White-Label.
- O backend agora consulta primeiramente os endpoints diretos (`/myAccount/commercialInfo` para o Titular e `/myAccount/accountNumber` para Agência/Conta), e faz fallback para `/accounts` em caso de falha. Isso garante que a identificação visual da conta no painel apareça corretamente tanto para Prod quanto para Sandbox.

## [5.3.0] - 2026-05-24

### Corrigido (Sandbox)
- Corrigida base URL da API Asaas Sandbox para `https://api-sandbox.asaas.com/v3` (endpoint correto conforme documentação).
- Adicionado tratamento robusto de resposta (verificação de content-type e fallback de leitura de texto) para evitar erro "Unexpected token '<'".
- Adicionados logs detalhados para diagnóstico de chamadas sandbox e header `User-Agent` (`AI-Project-OS/1.0`).## [5.2.0] - 2026-05-24

### Corrigido
- Endpoints da API Asaas Produção corrigidos para `/accounts` e `/finance/balance` (erro 404 resolvido, URL `api/v3` -> `v3`).
- Removido uso de endpoint inválido (`/myAccount`).
- Adicionados logs detalhados para diagnóstico de falhas no endpoint `/accounts`.## [5.1.0] - 2026-05-24

### Corrigido
- Validação da chave Asaas Produção agora é feita por chamada real à API de produção (endpoint `/myAccount` com fallback para `/accounts`, e leitura de saldo em `/finance/balance`), não mais por formato/regex.
- Removidas validações de prefixo, tamanho ou `includes` no fluxo de Produção que rejeitavam chaves válidas.
- Adicionados logs detalhados para diagnóstico do ambiente produção.

### Melhorado
- Mensagens de erro mais claras quando a chave pertence ao ambiente incorreto.

## [5.0.0] - 2026-05-24

### Adicionado
- Duas seções independentes na aba Configurações para API Asaas: Produção e Sandbox.
- Cada ambiente possui seu próprio campo de chave, botão de teste, status e exibição de dados.
- Lógica de prioridade para alimentar o dashboard: nome e saldo da Produção, agência/conta da Sandbox.
- Persistência separada das duas configurações no backend.

### Melhorado
- Store Zustand unificado para gerenciar as duas contas de forma estruturada.
- Card de resumo no canto superior direito agora exibe informações combinadas (Nome, Agência, Conta e Saldo) ao passar o mouse.
- Logs detalhados para diagnóstico isolado de cada ambiente.

### Segurança
- Impedida a mistura de chaves de produção com URL sandbox (e vice-versa), garantindo isolamento total.## [4.3.0] - 2026-05-24

### Removido
- Campos de agência e número da conta da página de configuração Asaas, pois não são fornecidos pela API padrão.

### Adicionado
- Layout moderno e responsivo na página de configuração Asaas (cards, ícones, animações).
- Store global Zustand `useAsaasStore` para gerenciar nome do titular e saldo.
- Card "Saldo Asaas" no dashboard principal, sincronizado com a página de configuração.
- Atualização automática do saldo a cada 1 segundo (polling) para manter os dados sempre atuais.
- Indicadores de loading e toasts de sucesso/erro.

### Melhorado
- Experiência visual e interatividade (hover, transições, glassmorphism).

## [4.1.0] - 2026-05-24

### Adicionado
- Exibição do **nome do titular** da conta Asaas no cabeçalho, obtido via endpoint `/v3/accounts`.
- Exibição do **saldo** da conta Asaas no cabeçalho, atualizado automaticamente.

### Corrigido
- O resumo "Asaas: não conectado" é substituído pelas informações reais quando o token é configurado.
- Dados permanecem visíveis após recarregar a página.

### Observação
- Agência e número da conta não são exibidos, pois a API padrão não os fornece de forma segura. A recomendação da Asaas é usar o modelo BaaS (White Label) para dados cadastrais completos.


## [3.6.0] - 2026-05-24

### Corrigido
- **Integração com API Asaas:** Corrigido o mapeamento dos campos retornados pela API. Agora, os dados de titular/empresa, agência e número da conta são extraídos corretamente do endpoint `/v3/accounts`.
- **Persistência de Dados:** As informações da conta (titular, agência, conta e saldo) agora são salvas no perfil do usuário e carregadas corretamente ao iniciar a página, garantindo que não desapareçam após atualização.
- **Exibição no Frontend:** Os dados são exibidos de forma organizada, cada um em sua própria linha, com fallback "Não informado" para campos vazios.

### Adicionado
- **Logs de Diagnóstico:** Adicionados logs detalhados no backend para registrar a resposta completa da API Asaas, facilitando futuras verificações.


## [3.5.0] - 2026-05-24

### 🐛 Corrigido (Mapeamento e Decriptação dos dados da conta Asaas)

- **Bug crítico em `payments.service.ts` — `decryptObject` corrompendo dados:** O método `decryptObject` tentava decriptar **todos** os campos do `bankConfig` como se fossem cifrados. Mas o novo formato salva apenas `apiKey` criptografada individualmente — os demais campos (`accountHolderName`, `agency`, `accountNumber`, `balance`) são texto plano. Resultado: esses campos eram "decriptados" produzindo lixo, e a `apiKey` era eventualmente passada ao adapter ainda criptografada, causando falha de autenticação na API Asaas.
- **Solução:** Adicionado método privado `resolveAdapterConfig()` no `PaymentsService` que detecta automaticamente o formato do `bankConfig` (novo vs antigo) e decripta apenas `apiKey` no formato novo. Aplicado em `processPaymentJob`, `getBalance`, `getTransactions` e `debugBalance`.
- **Endpoint `/myAccount` adicionado como primário** em `users.service.ts` e `asaas.adapter.ts`: este endpoint retorna os dados da conta de forma mais confiável que `/accounts`. Caso falhe (sandbox restrito), faz fallback para `/accounts`.
- **Logs diagnósticos adicionados**: todas as respostas da API Asaas são logadas em `debug` para facilitar diagnóstico futuro sem precisar de Postman.
- `dryRun` agora retorna `null` nos campos vazios (em vez de `"N/A"`) — consistente com o que o frontend espera.

### ✨ Melhorias

- `asaas.adapter.ts` (`getBalance`): agora também tenta `/myAccount` primeiro antes de `/accounts`, garantindo consistência entre salvar e consultar dados.
- Logs de extração em nível `LOG` (visível em produção) para confirmar os campos extraídos: `titular`, `agência`, `conta`, `saldo`.



### 🐛 Corrigido (Persistência dos dados Asaas — root cause definitivo)

- **Bug crítico em `settings/page.tsx`:** O `useEffect` de montagem chamava `getBalance()` (endpoint `/payments/balance`) para popular os dados da conta após confirmar que havia chave salva. Esse endpoint retorna um shape completamente diferente (`data.available`, `data.accountData`) que nunca corresponde ao esperado — resultado: `accountData` e `balance` ficavam `null` e o card da conta nunca renderizava após F5. Corrigido para usar diretamente os campos já persistidos retornados por `getBankConfig()` (`accountHolderName`, `agency`, `accountNumber`, `balance`).
- **Bug secundário em `handleTest` (path sem token novo):** Mesmo problema — chamava `getBalance()` com shape errado. Corrigido para chamar `getBankConfig()` e usar os campos persistidos.
- Dados da conta (titular, agência, conta, saldo) agora são carregados automaticamente ao acessar qualquer página do dashboard, garantindo que **não sumam após F5 ou fechar/abrir o navegador**.
- `AsaasSummary` (cabeçalho) simplificado para usar a nova ação `loadAsaasData` do store, eliminando lógica duplicada.

### ✨ Melhorias

- Adicionada ação `loadAsaasData(apiKey)` no store Zustand (`asaasStore.ts`) para centralizar a busca e hidratação dos dados da conta Asaas — qualquer componente pode chamá-la para garantir dados atualizados.
- `AccountData` no store agora aceita `null` nos campos opcionais, eliminando possíveis erros de tipo.
- Evento `asaas-config-updated` continua sendo disparado após salvar/remover configuração para atualização em tempo real do `AsaasSummary`.



### 🐛 Corrigido (Persistência dos dados Asaas)
- Os dados da conta (nome, agência, conta, saldo) agora são carregados automaticamente ao acessar a página de configuração ou o dashboard.
- Os campos não desaparecem mais após navegação ou recarregamento da página.

### ✨ Adicionado
- Estado global utilizando **Zustand** (`useAsaasStore`) para compartilhar os dados da conta Asaas de forma reativa entre os componentes do dashboard.
- Adicionado `useEffect` nos componentes `AsaasSummary` e `SettingsPage` para buscar os dados persistidos no backend ao montar a página, preenchendo o Zustand store.

### 🚀 Melhorias
- O resumo no cabeçalho (`AsaasSummary`) agora exibe consistentemente as informações da conta (se configurada), refletindo imediatamente mudanças feitas na página de configurações.

## [2.7.0] - 2026-05-23

### Removido
- Opção de selecionar ambiente (Sandbox/Produção) na configuração Asaas. Agora a integração usa URL base fixa (produção ou variável de ambiente).

### Adicionado
- Busca automática completa dos dados da conta Asaas: agência, número da conta e saldo.
- Exibição desses dados na página de configuração e no resumo do cabeçalho.
- Atualização do saldo sempre que o token é testado ou salvo.

### Corrigido
- Agora o sistema obtém e exibe agência, conta e saldo corretamente (antes estava N/A e R$ 0,00).

## [2.7.0] - 2026-05-23

### 🐛 Correções
- **Busca de Dados da Conta Asaas:** Corrigido o parse da resposta da API do Asaas ao salvar ou recuperar configurações. Os dados da conta bancária (agência, número da conta com dígito) agora são extraídos corretamente do objeto `accountNumber`, garantindo sua exibição correta no dashboard ao invés de "Agência: N/A" e "Conta: N/A".

## [2.6.0] - 2026-05-23

### ✨ Melhorias
- **Busca Automática de Dados da Conta Asaas:** Ao salvar o token, o backend agora consulta a API do Asaas para obter e armazenar automaticamente o titular, agência e número da conta.
- **Exibição de Resumo no Cabeçalho:** Foi criado o componente `AsaasSummary` que exibe um resumo da conta conectada (Agência/Conta/Titular) no canto superior direito, substituindo o botão de download da extensão.
- **Página de Configuração Melhorada:** A página de configuração do Asaas agora exibe as informações da conta e o saldo ao testar a conexão, antes de salvar.

### 🐛 Correções
- Removido o botão "Baixar Extensão" do cabeçalho global, movendo a funcionalidade para a página de extensões vinculadas, conforme solicitado.

### ⚙️ Técnico
- Atualizada a lógica do endpoint `PATCH /users/me/bank-config` para consultar e armazenar os dados da conta retornados pela API Asaas.

## [2.2.0] - 2026-05-23

### Adicionado
- Componente `AsaasSummary` no cabeçalho global (canto superior direito), exibindo agência, conta e nome do titular da conta Asaas conectada.
- Clique no resumo redireciona para a página de configuração Asaas.
- Evento `asaas-config-updated` para atualizar o resumo em tempo real após salvar/remover configuração.

### Corrigido
- Backend agora busca e armazena `accountHolderName`, `agency` e `accountNumber` ao validar o token Asaas (com tentativa em `GET /myAccount`, fallback em `GET /accounts` e `GET /wallet`).
- Endpoint `GET /api/v1/users/me/bank-config` retorna esses dados corretamente sem expor `apiKey`.

### Alterado
- Botão "Baixar Extensão" definitivamente removido do cabeçalho (já estava, agora garantido fora do header).

## [3.2.0] - 2026-05-23

### Adicionado
- Componente `AsaasSummary` no cabeçalho global, exibindo agência, conta e titular da conta Asaas conectada.
- Clique no resumo redireciona para a página de configuração Asaas.
- Botão "Baixar Extensão" movido para a página de extensões vinculadas.

### Removido
- Botão "Baixar Extensão" do cabeçalho global (canto superior direito).

### Melhorias
- O backend agora salva persistentemente os dados bancários da conta Asaas (`accountData`) dentro do campo `bankConfig`.
- Atualização automática do resumo Asaas após salvar ou remover configuração via evento customizado.
- Responsividade: em mobile, resumo vira ícone com tooltip.

## [3.1.0] - 2026-05-24

### Adicionado
- **Extrato de transações Asaas** — novo endpoint `GET /payments/transactions` no backend e página `/dashboard/payments/transactions` no frontend com paginação e indicadores de crédito/débito.
- **Validação de token antes de salvar** — ao configurar a API Key do Asaas, o sistema agora testa a conexão real com a API e só persiste se o token for válido (retorna erro 400 se inválido).
- **Dados da conta retornados ao salvar** — após validar e salvar o token, o backend retorna Nome, Agência, Conta e Saldo disponível para exibição imediata no dashboard.
- **Método `getTransactions()`** no `AsaasPaymentAdapter` consumindo `/financialTransactions` da API Asaas.
- **Interface `TransactionsOutput` e `TransactionItem`** adicionadas ao `payment-adapter.interface.ts`.
- **Link "Extrato"** adicionado na barra lateral (sidebar) com ícone `Receipt`.
- **Painel de Usuários** — página `/dashboard/users` com tabela de todos os usuários, status e provedor bancário.
- **Painel de Auditoria** — página `/dashboard/logs` exibindo histórico de todas as operações do sistema.

### Corrigido
- **Bug crítico (pagamentos falhando silenciosamente):** `processPaymentJob` estava passando `bankConfig` criptografado diretamente ao adapter. Adicionada descriptografia antes de instanciar o adapter — pagamentos automáticos agora funcionam corretamente.
- `LogsModule` corrigido: importação de `UserEntity` adicionada para resolver dependência do `ApiKeyGuard`.
- Erros de cache do servidor TypeScript no VS Code (logs.service.ts, logs.controller.ts) — código estava correto, apenas cache do editor precisava ser reiniciado.

### Alterado
- `UsersService.updateBankConfig()` agora injeta `PaymentAdapterFactory` para validar token em tempo real.
- `UsersModule` passou a importar `PaymentsModule` para disponibilizar o `PaymentAdapterFactory`.
- `StatsGrid` e `useAsaasBalance` já existentes foram mantidos — saldo atualiza a cada 30s automaticamente.

## [3.0.0] - 2026-05-23


### Alterado (BREAKING CHANGE)
- Removida a detecção visual de QR Code via jsQR (leitura de imagem/canvas).
- Substituída por **automação de clique no botão nativo de "Copiar QR Code"** da página.
- Prioridade: encontrar botão → clicar → capturar texto copiado → enviar.

### Adicionado
- Busca inteligente por botões usando texto visível, aria-label, title, data-testid, id, class.
- Logs detalhados de cada etapa (botão encontrado, clique, captura, envio).
- Fallback para captura via clipboard (polling e eventos copy/paste) caso o botão não seja encontrado.

### Corrigido
- Captura automática finalmente funcionando para sites com botão "Copiar código QR".
- Eliminada a necessidade de permissão `clipboardRead`? (ainda necessária, mas mantida).
## [2.0.1] - 2026-05-23

### Alterado (Extensao)
- Captura automatica por clipboard reforcada no `content.js`:
  - listener de `copy` em fase de captura com leitura de `navigator.clipboard.readText()` apos 50ms,
  - listener de `paste` com `event.clipboardData.getData('text/plain')`,
  - validacao estrita de payload Pix (`000201` + `0014BR.GOV.BCB.PIX`).
- Dedupe local de curtissima janela (1 segundo) para evitar reenvio imediato do mesmo payload copiado/colado em sequencia.
- Service worker com keep-alive via `chrome.alarms`:
  - alarme `keepAlive` a cada 30 segundos,
  - ping `GET /health` para manter atividade enquanto o Chrome estiver aberto,
  - recriacao do alarme em `onStartup` e `onInstalled`.

### Permissoes
- Confirmado `manifest.json` com `clipboardRead` e `alarms` para suportar captura automatica e keep-alive.

---

## [1.10.0] - 2026-05-23

### Adicionado (Backend & Dashboard)
- **Monitoramento Automático via WebSocket**: O backend (`QrGateway`) agora detecta handshakes e encerramentos de conexão WebSocket das extensões e emite os eventos em tempo real (`DEVICE_ONLINE` / `DEVICE_OFFLINE`) para o dashboard (sala do usuário).
- **Status Inicial no Carregamento**: Atualizado o endpoint `GET /extension/devices` no `ExtensionController` para incluir a propriedade `isOnline: boolean` (via consulta ao gateway). O frontend pré-popula o mapa local de presença `onlineStatus` imediatamente no carregamento da tela.
- **Sincronização no Dashboard**: A página de Extensões (`/dashboard/extensions`) escuta os eventos do socket e re-renderiza o ícone de Wi-Fi instantaneamente (verde para online, cinza para offline), sem precisar de recarregamento.
- **Manutenção de Verificação Manual**: Mantido o botão "Testar Conexão" para forçar testes manuais sob demanda, atualizando o mapa local e mantendo o status permanentemente reativo.

---

## [1.9.0] - 2026-05-23

### Adicionado
- Botão "Testar Conexão" na página de extensões vinculadas no Dashboard (`/dashboard/extensions`).
- Endpoint `POST /api/v1/extension/devices/:deviceId/test` para verificar se a extensão possui uma conexão WebSocket ativa.
- Manutenção do mapeamento de dispositivos conectados (`deviceSocketMap`) e método `isDeviceOnline` no `QrGateway` (Backend).

---

## [2.0.0] - 2026-05-23

### Alterado (Extensao)
- Mudanca completa de abordagem: captura de Pix agora e baseada em clipboard (eventos `copy` e `paste`), sem escaneamento visual de canvas/img.
- `content.js` simplificado para:
  - escutar `copy` em fase de captura,
  - ler `navigator.clipboard.readText()` apos 50ms,
  - validar payload Pix (`000201` + `BR.GOV.BCB.PIX`),
  - enviar `QR_DETECTED` automaticamente para o background.
- Fallback implementado no `copy`: se `clipboard.readText()` falhar, tenta capturar o texto selecionado via `window.getSelection()`.
- Listener de `paste` mantido como fallback adicional para capturar payload colado.
- Dedupe de envios mantido no `content.js` para evitar repeticao do mesmo payload.

### Removido
- Toda logica de leitura por imagem/QR visual (`jsQR`, scan em `canvas/img`, `MutationObserver` e loop de `setInterval` para escaneamento).
- Referencia a `jsQR.js` no `manifest.json` do template da extensao.
- Arquivo `jsQR.js` removido do template backend da extensao por nao ser mais utilizado.

### Permissoes
- Adicionada permissao `clipboardRead` no `manifest.json` para leitura da area de transferencia apos gesto de copia.

## [1.8.1] - 2026-05-22

### Corrigido
- **Sincronização de Status WebSocket no Popup**: O `background.js` agora retorna corretamente o status salvo no `chrome.storage.local` para chamadas `GET_STATUS`, operando de maneira assíncrona. Isso resolve a falha em que a extensão funcionava (ex: envio de testes), mas o painel insistia em mostrar "WebSocket Desconectado".
- O `popup.js` está garantidamente configurado para escutar o evento de mensagem `WS_STATUS` (para atualizações em tempo real) e reflete a interface gráfica condizente com a real conexão da ferramenta.

---

## [1.6.0] - 2026-05-22

### Corrigido (Extensão)
- Status do WebSocket agora reflete corretamente no popup (conectado/desconectado).
- Botão "Teste" agora gera um payload único a cada clique, evitando bloqueio por duplicidade.
- Captura automática de QR Code aprimorada: agora detecta também via colagem (Ctrl+V) e tem fallback periódico.
- Comunicação entre popup e background melhorada com mensagens de status.

### Corrigido (Backend)
- Endpoint `GET /api/v1/payments/balance` agora retorna 200 com saldo 0 quando o Asaas não está configurado (em vez de 400).
- Endpoint `GET /api/v1/payments` implementado para listar pagamentos do usuário.

### Melhorias
- Adicionado suporte a captura de QR via `paste` na extensão.
- Popup agora atualiza status em tempo real quando a conexão WebSocket muda.

### Dependências
- Nenhuma nova dependência.

---

## [1.5.0] - 2026-05-22

### Adicionado
- Endpoint `GET /api/v1/extension/download` para gerar extensão Chrome personalizada com device token embutido.
- Template da extensão com todos os arquivos necessários (Manifest V3, background, content, popup, ícones PNG válidos).
- Funcionalidade "Enviar QR de Teste" no popup da extensão.
- Página `/dashboard/extensions` listando dispositivos vinculados com opção de revogação.
- Botão "Baixar Extensão" na página `/dashboard/settings` com estado de loading e feedback.
- Validação do `manifest.json` dentro do método `generateExtensionZip` (lança erro se ausente na raiz do ZIP).

### Corrigido
- **Manifest ausente no ZIP** — `resolveTemplatePath()` agora verifica a existência de `manifest.json` no candidato antes de usá-lo, garantindo que o template correto (`extension-template/`) seja selecionado em vez de seu diretório pai.
- **Ícones PNG corrompidos** — recriados com estrutura PNG válida (IHDR + IDAT + IEND), tamanhos 16×16, 48×48 e 128×128.
- **Placeholders não substituídos** — regexes escapam corretamente os caracteres `{}`.
- **BOM UTF-8** — removido automaticamente de arquivos de texto antes de adicioná-los ao ZIP.
- **Arquivos binários (ícones)** — lidos como Buffer em vez de string UTF-8, evitando corrupção.
- **`host_permissions` inválidas** — removido `{{API_URL}}/*` do manifest (placeholder no campo URL causava JSON inválido após substituição de URL com caracteres especiais); substituído por `<all_urls>`.
- Erro 500 ao baixar extensão corrigido — `adm-zip` substitui `archiver` para geração síncrona em memória.

### Melhorias
- `background.js` reescrito: reconexão WebSocket robusta (sem múltiplos timers), URL WS construída corretamente de `http://host/api/v1` → `ws://host/`, notificação ao popup via `chrome.runtime.sendMessage`.
- `content.js` reescrito: deduplicação de payloads via `Set`, `MutationObserver` para detecção em SPAs, sem dependência externa (jsQR removido — detecção por texto EMV).
- `popup.js` reescrito: sincronização com `chrome.storage.local`, escuta de eventos do background em tempo real, feedback visual de sucesso/erro.
- Logging aprimorado no backend (`Logger`) para rastreamento do caminho do template e entradas do ZIP.

### Dependências
- `adm-zip` adicionado ao backend.
- `@types/adm-zip` adicionado como devDependency no backend.

---

## [1.4.0] - 2026-05-22

### Adicionado
- Página de configuração de API Asaas no dashboard (salvar chave, testar conexão, exibir saldo).
- Exibição de saldo Asaas no `StatsGrid` com atualização periódica via `useAsaasBalance`.
- Hook `useAsaasBalance` para buscar saldo com polling.

### Corrigido
- Integração com Asaas agora usa a chave salva pelo usuário (criptografada), não mais variável de ambiente.
- Endpoint `PATCH /api/v1/users/me/bank-config` para salvar e criptografar configuração bancária.
- Endpoint `GET /api/v1/users/me/bank-config` retorna config mascarada (sem expor a chave).
- Endpoint `GET /api/v1/payments/balance` usa adapter do usuário com bankConfig decriptografado.
