@echo off
title BACKEND - AI OS (porta 3001)
color 0B
cd /d "C:\Users\RUAN CPA\Documents\AI PROJECT OPERATING SYSTEM"
echo.
echo  [BACKEND] Iniciando NestJS na porta 3001...
echo  Diretorio: %CD%
echo.
npm run dev --workspace=@aios/backend
pause
