@echo off
title AI OS - SISTEMA COMPLETO
color 0A

:: Garantir que estamos no diretorio correto
cd /d "C:\Users\RUAN CPA\Documents\AI PROJECT OPERATING SYSTEM"

echo ============================================================
echo              AI OS - INICIANDO SISTEMA COMPLETO
echo ============================================================
echo.

:: [1/4] Limpar portas
echo [1/4] Limpando portas 3000 e 3001...
for /f "tokens=5" %%a in ('netstat -ano ^| findstr :3001 ^| findstr LISTENING') do taskkill /F /PID %%a >nul 2>nul
for /f "tokens=5" %%a in ('netstat -ano ^| findstr :3000 ^| findstr LISTENING') do taskkill /F /PID %%a >nul 2>nul
timeout /t 2 /nobreak >nul
echo [OK] Portas liberadas
echo.

:: [2/4] Iniciar BACKEND em janela separada
echo [2/4] Iniciando BACKEND (porta 3001)...
start "BACKEND AI OS" "C:\Users\RUAN CPA\Documents\AI PROJECT OPERATING SYSTEM\_start_backend.bat"
echo Aguardando 5 segundos para o backend subir...
timeout /t 5 /nobreak >nul
echo [OK] Backend iniciando
echo.

:: [3/4] Iniciar DASHBOARD em janela separada
echo [3/4] Iniciando DASHBOARD (porta 3000)...
start "DASHBOARD AI OS" "C:\Users\RUAN CPA\Documents\AI PROJECT OPERATING SYSTEM\_start_dashboard.bat"
echo Aguardando 5 segundos para o dashboard subir...
timeout /t 5 /nobreak >nul
echo [OK] Dashboard iniciando
echo.

:: [4/4] Abrir navegador
echo [4/4] Abrindo navegador...
timeout /t 3 /nobreak >nul
start chrome http://localhost:3000
start chrome http://localhost:3001/api/v1/health

echo.
echo ============================================================
echo                     SISTEMA OPERACIONAL!
echo ============================================================
echo.
echo    BACKEND:   http://localhost:3001
echo    FRONTEND:  http://localhost:3000
echo.
echo    ATENCAO: Nao feche as janelas do terminal.
echo.
pause